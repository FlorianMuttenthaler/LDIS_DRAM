#!/bin/bash

# Script to simulate TRNG-VHDL designs

# Delete unused files
rm -f *.o *.cf *.vcd

# Simulate design

# Syntax check
ghdl -s fifo.vhd fifo_pkg.vhd
ghdl -s ram2ddrxadc.vhd ram2ddrxadc_pkg.vhd
ghdl -s design.vhd Memory_pkg.vhd tb2.vhd

# Compile the design
ghdl -a fifo.vhd fifo_pkg.vhd
ghdl -a ram2ddrxadc.vhd ram2ddrxadc_pkg.vhd
ghdl -a design.vhd Memory_pkg.vhd tb2.vhd

# Create executable
ghdl -e memory_tb2

# Simulate
ghdl -r memory_tb2 --vcd=memory_tb2.vcd

# Show simulation result as wave form
gtkwave memory_tb2.vcd &

# Delete unused files
rm -f *.o *.cf
